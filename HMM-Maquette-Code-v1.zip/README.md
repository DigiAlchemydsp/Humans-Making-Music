# HMM — Human Making Music

Code de la maquette HMM : sessions live, ateliers Ableton Live et performance électronique, Ottawa.

Cette version reprend la maquette fournie le 9 novembre 2026. Elle est autonome : HTML, CSS et JavaScript, sans framework, sans téléchargement de polices, sans dépendances et sans compte requis. Tous les titres et blocs sont du vrai HTML modifiable.

## Ouvrir la maquette

Décompresser le ZIP et ouvrir **index.html** dans un navigateur récent. Cela fonctionne sans installer Node.js.

Pour développer avec un serveur local, installer Node.js 18 ou plus récent, ouvrir un terminal dans ce dossier, puis :

```sh
npm run dev
```

Ouvrir http://localhost:4173. Aucune commande `npm install` n'est nécessaire. Le serveur fourni sert uniquement au développement local.

## Fichiers à modifier

| Fichier | Contenu |
| --- | --- |
| `index.html` | Textes, sections, informations des ateliers et fenêtres de détails |
| `styles.css` | Mise en page ordinateur/mobile, typographie, couleurs |
| `config.js` | Titre/artistes de la session, vidéo, affiche, email et réseaux HMM |
| `app.js` | Interactions, fenêtres accessibles, lecture vidéo et liens |
| `assets/` | Logos SVG et image de référence |
| `scripts/serve.mjs` | Petit serveur de développement sans dépendances |
| `scripts/build.mjs` | Copie des fichiers du site dans `dist/` |

## Ajouter les contenus réels

Dans `config.js`, remplacer les valeurs `null` seulement quand les liens sont connus :

- `session.videoUrl` : URL HTTPS de la session (YouTube, Vimeo, etc.). Un bouton ouvre le fournisseur dans un nouvel onglet, sans charger de lecteur tiers avant le clic.
- `session.videoFile` : chemin d'un MP4/WebM local ou URL directe. Un lecteur HTML natif apparaît dans la fenêtre de session. Prioritaire sur `videoUrl`.
- `session.poster` : chemin d'une photo seule, par exemple `assets/session-001.jpg`. Elle remplace automatiquement l'image de référence et reçoit un bouton de lecture dessiné en CSS.
- `contactEmail`, `instagramUrl`, `youtubeUrl` : coordonnées officielles de HMM.

Le statut devient « Watch now » dès qu'une vidéo valide est configurée. Sans vidéo, le bouton présente les détails « Coming soon ». Aucun enregistrement, formulaire, paiement ou message automatique n'est activé. Les réseaux non renseignés affichent un message explicite ; aucun compte HMM n'a été inventé. Ne mettre aucun secret dans les fichiers du site.

Les descriptifs complémentaires des ateliers sont des textes de présentation à affiner ensemble. Aucune date ni réservation n'est annoncée.

## Fidélité à la maquette

La page conserve le fond clair, le logo HMM, le titre sur deux lignes, la grande session, la section ateliers en deux colonnes sur ordinateur et le pied de page minimal. Sur petit écran, les blocs se réorganisent verticalement.

Le fichier `assets/hmm-reference.png` est la maquette fournie. Pour conserver **exactement** la photographie de cette maquette, elle est cadrée dans le bloc session par CSS. Le bouton de lecture visible dans la photographie est celui de la référence ; le conteneur est un véritable bouton accessible. Le reste du site est du HTML/CSS, pas une image de page. Cette image sert de visuel de concept, et ne prétend pas être une photo des fondateurs. Une photo de session originale pourra la remplacer via `session.poster`, sans toucher à la mise en page. Les logos SVG sont les fichiers HMM existants.

## Importer dans le dépôt partagé

Dépôt prévu : https://github.com/DigiAlchemydsp/Humans-Making-Music

1. Décompresser le ZIP.
2. Sur la page du dépôt vide, choisir **uploading an existing file**.
3. Ajouter le **contenu** du dossier : `index.html` doit être à la racine, avec les dossiers `assets` et `scripts`. Ne pas déposer seulement le ZIP.
4. Valider avec le message `Import initial de la maquette HMM`.
5. Ajouter aussi `.gitignore` si le système masque les fichiers commençant par un point. GitHub Desktop ou Git incluent ce fichier plus facilement.

Pour une équipe utilisant déjà Git, cloner le dépôt, copier ces fichiers dans le clone et créer un commit. Cette livraison n'a pas été importée dans GitHub et ne déclenche aucun déploiement.

## Travailler à deux

Garder `main` comme version de référence. Créer une branche pour chaque changement, par exemple `feature/workshops` ou `design/homepage`, puis ouvrir une pull request. Relire avant d'intégrer. Un seul fichier de configuration centralise les liens.

## Contrôler et préparer un hébergement

```sh
npm run check
npm run build
```

`dist/` contient uniquement les fichiers publics. Ils sont compatibles avec un hébergement statique et les sous-répertoires grâce aux chemins relatifs. Le ZIP ne configure pas d'hébergement, de domaine, d'analytics ni de workflow de déploiement.

## Accessibilité

Navigation au clavier, lien d'accès au contenu, indicateurs de focus, textes alternatifs, dialogues HTML natifs refermables par Échap et restitution du focus. La préférence de réduction des animations est respectée. Les liens d'ancrage et les textes restent consultables sans JavaScript ; les fenêtres de détails nécessitent JavaScript.

## Droits

Projet privé HMM. Aucune licence open source n'est accordée par cette livraison. La propriété et les droits de réutilisation des éléments de marque et des visuels restent à déterminer par leurs ayants droit avant une redistribution publique.
